class user_rules():
    def __init__(self, type, threshold, limit_type):
        self.type = type
        self.threshold = threshold
        self.limit_type = limit_type

